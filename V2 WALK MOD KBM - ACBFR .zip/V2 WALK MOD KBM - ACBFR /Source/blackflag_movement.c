/*
  ACBFR KBM Walk-by-Default native version.dll proxy
  
*/

#if defined(_M_IX86) || defined(__i386__)
# define WINAPI __stdcall
# define CALLBACK __stdcall
#else
# define WINAPI
# define CALLBACK
#endif
#define DLLIMPORT __declspec(dllimport)
#define DLLEXPORT __declspec(dllexport)

typedef void* HANDLE; typedef void* HMODULE; typedef void* HINSTANCE; typedef void* HWND; typedef void* HHOOK; typedef void* HLOCAL;
typedef unsigned long DWORD; typedef long LONG; typedef unsigned int UINT; typedef unsigned short WORD; typedef unsigned char BYTE;
typedef int BOOL; typedef long long LONGLONG; typedef unsigned long long ULONGLONG; typedef unsigned long long ULONG_PTR; typedef long long LONG_PTR;
typedef ULONG_PTR WPARAM; typedef LONG_PTR LPARAM; typedef LONG_PTR LRESULT; typedef void* LPVOID; typedef const void* LPCVOID;
typedef char CHAR; typedef const CHAR* LPCSTR; typedef CHAR* LPSTR; typedef unsigned short WCHAR; typedef const WCHAR* LPCWSTR; typedef WCHAR* LPWSTR;
typedef DWORD* LPDWORD; typedef UINT* PUINT; typedef void* FARPROC;
#define TRUE 1
#define FALSE 0
#define NULL ((void*)0)
#define MAX_PATH 260
#define DLL_PROCESS_ATTACH 1
#define ERROR_PROC_NOT_FOUND 127
#define VK_SHIFT 0x10
#define VK_CONTROL 0x11
#define VK_LSHIFT 0xA0
#define VK_RSHIFT 0xA1
#define VK_LCONTROL 0xA2
#define VK_F6 0x75
#define INPUT_KEYBOARD 1
#define KEYEVENTF_KEYUP 0x0002
#define WH_KEYBOARD_LL 13
#define LLKHF_INJECTED 0x10
#define WM_KEYDOWN 0x0100
#define WM_KEYUP 0x0101
#define WM_SYSKEYDOWN 0x0104
#define WM_SYSKEYUP 0x0105

typedef struct tagKEYBDINPUT { WORD wVk; WORD wScan; DWORD dwFlags; DWORD time; ULONG_PTR dwExtraInfo; } KEYBDINPUT;
typedef struct tagINPUT { DWORD type; union { KEYBDINPUT ki; unsigned char pad[32]; }; } INPUT;
typedef struct tagKBDLLHOOKSTRUCT { DWORD vkCode; DWORD scanCode; DWORD flags; DWORD time; ULONG_PTR dwExtraInfo; } KBDLLHOOKSTRUCT;
typedef struct tagPOINT { LONG x; LONG y; } POINT;
typedef struct tagMSG { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; POINT pt; DWORD lPrivate; } MSG;
typedef LRESULT (CALLBACK *HOOKPROC)(int,WPARAM,LPARAM);
typedef DWORD (WINAPI *THREADPROC)(LPVOID);

DLLIMPORT UINT WINAPI GetSystemDirectoryW(LPWSTR,UINT);
DLLIMPORT DWORD WINAPI GetModuleFileNameW(HMODULE,LPWSTR,DWORD);
DLLIMPORT HMODULE WINAPI LoadLibraryW(LPCWSTR);
DLLIMPORT FARPROC WINAPI GetProcAddress(HMODULE,LPCSTR);
DLLIMPORT HANDLE WINAPI CreateThread(LPVOID,ULONG_PTR,THREADPROC,LPVOID,DWORD,LPDWORD);
DLLIMPORT BOOL WINAPI CloseHandle(HANDLE);
DLLIMPORT DWORD WINAPI GetCurrentProcessId(void);
DLLIMPORT void WINAPI Sleep(DWORD);
DLLIMPORT UINT WINAPI GetPrivateProfileIntW(LPCWSTR,LPCWSTR,int,LPCWSTR);
DLLIMPORT LONG WINAPI InterlockedCompareExchange(volatile LONG*,LONG,LONG);
DLLIMPORT LONG WINAPI InterlockedExchange(volatile LONG*,LONG);
DLLIMPORT BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
DLLIMPORT void WINAPI SetLastError(DWORD);

DLLIMPORT short WINAPI GetAsyncKeyState(int);
DLLIMPORT HWND WINAPI GetForegroundWindow(void);
DLLIMPORT DWORD WINAPI GetWindowThreadProcessId(HWND,LPDWORD);
DLLIMPORT UINT WINAPI SendInput(UINT,INPUT*,int);
DLLIMPORT HHOOK WINAPI SetWindowsHookExW(int,HOOKPROC,HINSTANCE,DWORD);
DLLIMPORT BOOL WINAPI UnhookWindowsHookEx(HHOOK);
DLLIMPORT LRESULT WINAPI CallNextHookEx(HHOOK,int,WPARAM,LPARAM);
DLLIMPORT BOOL WINAPI GetMessageW(MSG*,HWND,UINT,UINT);
DLLIMPORT BOOL WINAPI TranslateMessage(const MSG*);
DLLIMPORT LRESULT WINAPI DispatchMessageW(const MSG*);

static HMODULE g_self; static DWORD g_pid; static HHOOK g_hook;
static volatile LONG g_enabled=1,g_kbmEnabled=1,g_manualJog=0,g_suppressWalkUp=0,g_walkInjected=0;
static int g_walkKey=VK_LCONTROL,g_sprintKey=VK_LSHIFT,g_forward='W',g_back='S',g_left='A',g_right='D',g_toggle=VK_F6;
static HMODULE g_realVersion; static volatile LONG g_realState=0;

#define PDECL(n) static FARPROC p_##n
PDECL(GetFileVersionInfoA); PDECL(GetFileVersionInfoByHandle); PDECL(GetFileVersionInfoExA); PDECL(GetFileVersionInfoExW);
PDECL(GetFileVersionInfoSizeA); PDECL(GetFileVersionInfoSizeExA); PDECL(GetFileVersionInfoSizeExW); PDECL(GetFileVersionInfoSizeW); PDECL(GetFileVersionInfoW);
PDECL(VerFindFileA); PDECL(VerFindFileW); PDECL(VerInstallFileA); PDECL(VerInstallFileW); PDECL(VerLanguageNameA); PDECL(VerLanguageNameW); PDECL(VerQueryValueA); PDECL(VerQueryValueW);
#undef PDECL

static int wlen(const WCHAR*s){int n=0;while(s&&s[n])n++;return n;}
static void wcat(WCHAR*d,const WCHAR*s){int n=wlen(d),i=0;while(s[i]){d[n+i]=s[i];i++;}d[n+i]=0;}
static WCHAR* wlastslash(WCHAR*s){WCHAR*r=0;int i=0;while(s[i]){if(s[i]=='\\')r=&s[i];i++;}return r;}
static void zero_mem(void*p,UINT n){BYTE*b=(BYTE*)p;while(n--)*b++=0;}

static BOOL ensure_real(void){
  LONG st=InterlockedCompareExchange(&g_realState,1,0);
  if(st==0){
    WCHAR path[MAX_PATH+32]; static const WCHAR name[]={ 'v','e','r','s','i','o','n','.','d','l','l',0};
    UINT n=GetSystemDirectoryW(path,MAX_PATH); if(!n||n>=MAX_PATH){InterlockedExchange(&g_realState,0);return FALSE;}
    if(path[n-1]!='\\'){path[n++]='\\';path[n]=0;} wcat(path,name); g_realVersion=LoadLibraryW(path);
    if(!g_realVersion){InterlockedExchange(&g_realState,0);return FALSE;}
#define R(n) p_##n=GetProcAddress(g_realVersion,#n)
    R(GetFileVersionInfoA);R(GetFileVersionInfoByHandle);R(GetFileVersionInfoExA);R(GetFileVersionInfoExW);R(GetFileVersionInfoSizeA);R(GetFileVersionInfoSizeExA);R(GetFileVersionInfoSizeExW);R(GetFileVersionInfoSizeW);R(GetFileVersionInfoW);R(VerFindFileA);R(VerFindFileW);R(VerInstallFileA);R(VerInstallFileW);R(VerLanguageNameA);R(VerLanguageNameW);R(VerQueryValueA);R(VerQueryValueW);
#undef R
    InterlockedExchange(&g_realState,2); return TRUE;
  }
  while(InterlockedCompareExchange(&g_realState,0,0)==1) Sleep(1);
  return g_realVersion!=0;
}
static BOOL kd(int vk){return (GetAsyncKeyState(vk)&0x8000)!=0;}
static BOOL moving(void){return kd(g_forward)||kd(g_back)||kd(g_left)||kd(g_right);}
static BOOL focused(void){DWORD p=0;HWND h=GetForegroundWindow();if(!h)return FALSE;GetWindowThreadProcessId(h,&p);return p==g_pid;}
static BOOL sprint(void){if(g_sprintKey==VK_SHIFT||g_sprintKey==VK_LSHIFT)return kd(VK_SHIFT)||kd(VK_LSHIFT)||kd(VK_RSHIFT);return kd(g_sprintKey);}
static void walk_key(BOOL down){
  LONG was=InterlockedCompareExchange(&g_walkInjected,0,0); INPUT in;
  if((down&&was)||(!down&&!was))return; zero_mem(&in,sizeof(in)); in.type=INPUT_KEYBOARD; in.ki.wVk=(WORD)g_walkKey; in.ki.dwFlags=down?0:KEYEVENTF_KEYUP;
  if(SendInput(1,&in,sizeof(in))==1)InterlockedExchange(&g_walkInjected,down?1:0);
}
static LRESULT CALLBACK hookproc(int code,WPARAM wp,LPARAM lp){
  if(code>=0&&lp){KBDLLHOOKSTRUCT*k=(KBDLLHOOKSTRUCT*)lp;if(!(k->flags&LLKHF_INJECTED)){
    BOOL isWalk=((int)k->vkCode==g_walkKey); if(g_walkKey==VK_LCONTROL&&(k->vkCode==VK_CONTROL||k->vkCode==VK_LCONTROL)&&k->scanCode==0x1D)isWalk=TRUE;
    if(isWalk&&InterlockedCompareExchange(&g_kbmEnabled,0,0)&&InterlockedCompareExchange(&g_enabled,0,0)&&focused()&&moving()){
      BOOL dn=(wp==WM_KEYDOWN||wp==WM_SYSKEYDOWN),up=(wp==WM_KEYUP||wp==WM_SYSKEYUP);
      if(dn&&!InterlockedCompareExchange(&g_manualJog,0,0)){InterlockedExchange(&g_manualJog,1);InterlockedExchange(&g_suppressWalkUp,1);walk_key(FALSE);return 1;}
      if(up&&InterlockedCompareExchange(&g_suppressWalkUp,0,0)){InterlockedExchange(&g_suppressWalkUp,0);return 1;}
    }
  }} return CallNextHookEx(g_hook,code,wp,lp);
}
static DWORD WINAPI hook_thread(LPVOID x){MSG m;(void)x;g_hook=SetWindowsHookExW(WH_KEYBOARD_LL,hookproc,g_self,0);if(!g_hook)return 0;while(GetMessageW(&m,0,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}UnhookWindowsHookEx(g_hook);g_hook=0;return 0;}
static void load_ini(void){
  WCHAR path[MAX_PATH]; WCHAR*slash; static const WCHAR ini[]={ 'b','l','a','c','k','f','l','a','g','_','m','o','v','e','m','e','n','t','.','i','n','i',0};
  static const WCHAR sec[]={ 'K','e','y','b','o','a','r','d','M','o','u','s','e',0};
static const WCHAR k_en[]={'K','e','y','b','o','a','r','d','W','a','l','k','B','y','D','e','f','a','u','l','t',0};
  static const WCHAR k_walk[]={'K','e','y','b','o','a','r','d','W','a','l','k','K','e','y',0};
  static const WCHAR k_sp[]={'K','e','y','b','o','a','r','d','S','p','r','i','n','t','K','e','y',0};
  static const WCHAR k_f[]={'K','e','y','b','o','a','r','d','F','o','r','w','a','r','d','K','e','y',0};
  static const WCHAR k_b[]={'K','e','y','b','o','a','r','d','B','a','c','k','K','e','y',0};
  static const WCHAR k_l[]={'K','e','y','b','o','a','r','d','L','e','f','t','K','e','y',0};
  static const WCHAR k_r[]={'K','e','y','b','o','a','r','d','R','i','g','h','t','K','e','y',0};
  static const WCHAR k_t[]={'K','e','y','b','o','a','r','d','T','o','g','g','l','e','K','e','y',0};
  if(!GetModuleFileNameW(g_self,path,MAX_PATH))return;slash=wlastslash(path);if(slash)*(slash+1)=0;else path[0]=0;wcat(path,ini);
  InterlockedExchange(&g_kbmEnabled,GetPrivateProfileIntW(sec,k_en,1,path)?1:0);g_walkKey=(int)GetPrivateProfileIntW(sec,k_walk,VK_LCONTROL,path);g_sprintKey=(int)GetPrivateProfileIntW(sec,k_sp,VK_LSHIFT,path);g_forward=(int)GetPrivateProfileIntW(sec,k_f,'W',path);g_back=(int)GetPrivateProfileIntW(sec,k_b,'S',path);g_left=(int)GetPrivateProfileIntW(sec,k_l,'A',path);g_right=(int)GetPrivateProfileIntW(sec,k_r,'D',path);g_toggle=(int)GetPrivateProfileIntW(sec,k_t,VK_F6,path);
}
static DWORD WINAPI main_thread(LPVOID x){BOOL old=FALSE;(void)x;g_pid=GetCurrentProcessId();load_ini();{HANDLE h=CreateThread(0,0,hook_thread,0,0,0);if(h)CloseHandle(h);}for(;;){BOOL f=focused(),t=kd(g_toggle);if(f&&t&&!old){LONG ns=!InterlockedCompareExchange(&g_enabled,0,0);InterlockedExchange(&g_enabled,ns);if(!ns){walk_key(FALSE);InterlockedExchange(&g_manualJog,0);InterlockedExchange(&g_suppressWalkUp,0);}}old=t;if(!InterlockedCompareExchange(&g_kbmEnabled,0,0)||!InterlockedCompareExchange(&g_enabled,0,0)||!f){walk_key(FALSE);if(!f){InterlockedExchange(&g_manualJog,0);InterlockedExchange(&g_suppressWalkUp,0);}Sleep(8);continue;}if(!moving()){walk_key(FALSE);InterlockedExchange(&g_manualJog,0);InterlockedExchange(&g_suppressWalkUp,0);}else if(sprint()||InterlockedCompareExchange(&g_manualJog,0,0))walk_key(FALSE);else walk_key(TRUE);Sleep(8);} }

#define NEED(p,fail) do{if(!ensure_real()||!(p)){SetLastError(ERROR_PROC_NOT_FOUND);return(fail);}}while(0)
DLLEXPORT BOOL WINAPI GetFileVersionInfoA(LPCSTR a,DWORD b,DWORD c,LPVOID d){typedef BOOL(WINAPI*F)(LPCSTR,DWORD,DWORD,LPVOID);NEED(p_GetFileVersionInfoA,FALSE);return((F)p_GetFileVersionInfoA)(a,b,c,d);} 
DLLEXPORT BOOL WINAPI GetFileVersionInfoByHandle(DWORD a,HANDLE b,DWORD c,LPVOID d){typedef BOOL(WINAPI*F)(DWORD,HANDLE,DWORD,LPVOID);NEED(p_GetFileVersionInfoByHandle,FALSE);return((F)p_GetFileVersionInfoByHandle)(a,b,c,d);} 
DLLEXPORT BOOL WINAPI GetFileVersionInfoExA(DWORD a,LPCSTR b,DWORD c,DWORD d,LPVOID e){typedef BOOL(WINAPI*F)(DWORD,LPCSTR,DWORD,DWORD,LPVOID);NEED(p_GetFileVersionInfoExA,FALSE);return((F)p_GetFileVersionInfoExA)(a,b,c,d,e);} 
DLLEXPORT BOOL WINAPI GetFileVersionInfoExW(DWORD a,LPCWSTR b,DWORD c,DWORD d,LPVOID e){typedef BOOL(WINAPI*F)(DWORD,LPCWSTR,DWORD,DWORD,LPVOID);NEED(p_GetFileVersionInfoExW,FALSE);return((F)p_GetFileVersionInfoExW)(a,b,c,d,e);} 
DLLEXPORT DWORD WINAPI GetFileVersionInfoSizeA(LPCSTR a,LPDWORD b){typedef DWORD(WINAPI*F)(LPCSTR,LPDWORD);NEED(p_GetFileVersionInfoSizeA,0);return((F)p_GetFileVersionInfoSizeA)(a,b);} 
DLLEXPORT DWORD WINAPI GetFileVersionInfoSizeExA(DWORD a,LPCSTR b,LPDWORD c){typedef DWORD(WINAPI*F)(DWORD,LPCSTR,LPDWORD);NEED(p_GetFileVersionInfoSizeExA,0);return((F)p_GetFileVersionInfoSizeExA)(a,b,c);} 
DLLEXPORT DWORD WINAPI GetFileVersionInfoSizeExW(DWORD a,LPCWSTR b,LPDWORD c){typedef DWORD(WINAPI*F)(DWORD,LPCWSTR,LPDWORD);NEED(p_GetFileVersionInfoSizeExW,0);return((F)p_GetFileVersionInfoSizeExW)(a,b,c);} 
DLLEXPORT DWORD WINAPI GetFileVersionInfoSizeW(LPCWSTR a,LPDWORD b){typedef DWORD(WINAPI*F)(LPCWSTR,LPDWORD);NEED(p_GetFileVersionInfoSizeW,0);return((F)p_GetFileVersionInfoSizeW)(a,b);} 
DLLEXPORT BOOL WINAPI GetFileVersionInfoW(LPCWSTR a,DWORD b,DWORD c,LPVOID d){typedef BOOL(WINAPI*F)(LPCWSTR,DWORD,DWORD,LPVOID);NEED(p_GetFileVersionInfoW,FALSE);return((F)p_GetFileVersionInfoW)(a,b,c,d);} 
DLLEXPORT DWORD WINAPI VerFindFileA(DWORD a,LPCSTR b,LPCSTR c,LPCSTR d,LPSTR e,PUINT f,LPSTR g,PUINT h){typedef DWORD(WINAPI*F)(DWORD,LPCSTR,LPCSTR,LPCSTR,LPSTR,PUINT,LPSTR,PUINT);NEED(p_VerFindFileA,0);return((F)p_VerFindFileA)(a,b,c,d,e,f,g,h);} 
DLLEXPORT DWORD WINAPI VerFindFileW(DWORD a,LPCWSTR b,LPCWSTR c,LPCWSTR d,LPWSTR e,PUINT f,LPWSTR g,PUINT h){typedef DWORD(WINAPI*F)(DWORD,LPCWSTR,LPCWSTR,LPCWSTR,LPWSTR,PUINT,LPWSTR,PUINT);NEED(p_VerFindFileW,0);return((F)p_VerFindFileW)(a,b,c,d,e,f,g,h);} 
DLLEXPORT DWORD WINAPI VerInstallFileA(DWORD a,LPCSTR b,LPCSTR c,LPCSTR d,LPCSTR e,LPCSTR f,LPSTR g,PUINT h){typedef DWORD(WINAPI*F)(DWORD,LPCSTR,LPCSTR,LPCSTR,LPCSTR,LPCSTR,LPSTR,PUINT);NEED(p_VerInstallFileA,0);return((F)p_VerInstallFileA)(a,b,c,d,e,f,g,h);} 
DLLEXPORT DWORD WINAPI VerInstallFileW(DWORD a,LPCWSTR b,LPCWSTR c,LPCWSTR d,LPCWSTR e,LPCWSTR f,LPWSTR g,PUINT h){typedef DWORD(WINAPI*F)(DWORD,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPWSTR,PUINT);NEED(p_VerInstallFileW,0);return((F)p_VerInstallFileW)(a,b,c,d,e,f,g,h);} 
DLLEXPORT DWORD WINAPI VerLanguageNameA(DWORD a,LPSTR b,DWORD c){typedef DWORD(WINAPI*F)(DWORD,LPSTR,DWORD);NEED(p_VerLanguageNameA,0);return((F)p_VerLanguageNameA)(a,b,c);} 
DLLEXPORT DWORD WINAPI VerLanguageNameW(DWORD a,LPWSTR b,DWORD c){typedef DWORD(WINAPI*F)(DWORD,LPWSTR,DWORD);NEED(p_VerLanguageNameW,0);return((F)p_VerLanguageNameW)(a,b,c);} 
DLLEXPORT BOOL WINAPI VerQueryValueA(LPCVOID a,LPCSTR b,LPVOID*c,PUINT d){typedef BOOL(WINAPI*F)(LPCVOID,LPCSTR,LPVOID*,PUINT);NEED(p_VerQueryValueA,FALSE);return((F)p_VerQueryValueA)(a,b,c,d);} 
DLLEXPORT BOOL WINAPI VerQueryValueW(LPCVOID a,LPCWSTR b,LPVOID*c,PUINT d){typedef BOOL(WINAPI*F)(LPCVOID,LPCWSTR,LPVOID*,PUINT);NEED(p_VerQueryValueW,FALSE);return((F)p_VerQueryValueW)(a,b,c,d);} 

BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID reserved){(void)reserved;if(reason==DLL_PROCESS_ATTACH){HANDLE t;g_self=h;DisableThreadLibraryCalls(h);t=CreateThread(0,0,main_thread,0,0,0);if(t)CloseHandle(t);}return TRUE;}
