@echo off
setlocal
cd /d "%~dp0"

where cl.exe >nul 2>nul
if errorlevel 1 (
    echo ERROR: cl.exe was not found.
    echo.
    echo Open:
    echo   x64 Native Tools Command Prompt for VS
    echo.
    echo Then run this BAT again.
    pause
    exit /b 1
)

if not exist "Build\x64" mkdir "Build\x64"

echo ============================================================
echo   ACBFR KBM WALK MOD - SOURCE-MATCHED x64 BUILD
echo ============================================================
echo.

cl.exe /nologo /O2 /W4 /LD /GS- /D_WIN64 ^
  "blackflag_movement.c" ^
  kernel32.lib user32.lib ^
  /link /DEF:"version.def" /OUT:"Build\x64\version.dll" /SUBSYSTEM:WINDOWS

if errorlevel 1 (
    echo.
    echo BUILD FAILED.
    pause
    exit /b 1
)

echo.
echo BUILD OK:
echo   Source\Build\x64\version.dll
echo.
pause
