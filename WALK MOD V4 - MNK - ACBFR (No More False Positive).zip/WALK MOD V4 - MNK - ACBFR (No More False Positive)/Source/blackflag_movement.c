/*
    Assassin's Creed Black Flag Resynced - KBM Walk Mod
    Reconstructed buildable source for the supplied WALK MOD KBM - ACBFR package.

    IMPORTANT:
    The uploaded RAR contained only version.dll + blackflag_movement.ini for
    x86/x64. The original compiler source was not present. This source was
    reconstructed from the supplied binaries' exported functions, symbols,
    configuration keys, and observed control flow so the package has readable,
    buildable development source without replacing the known-working binaries.

    Runtime behavior:
      - Walk by default while moving with WASD by holding the game's native walk key.
      - Tap the native walk key while moving to enter jog override.
      - Stopping movement resets jog override back to walk-by-default.
      - Hold Shift to sprint (walk injection released while sprinting).
      - F6 toggles the movement modification.
      - Only acts while the game window owns the foreground.
      - version.dll proxies the real Windows System32 version.dll exports.
*/

#define WIN32_LEAN_AND_MEAN

/* Keep Windows headers from declaring the version APIs under the names that
   this proxy itself exports. */
#define GetFileVersionInfoA          WINSDK_GetFileVersionInfoA
#define GetFileVersionInfoByHandle   WINSDK_GetFileVersionInfoByHandle
#define GetFileVersionInfoExA        WINSDK_GetFileVersionInfoExA
#define GetFileVersionInfoExW        WINSDK_GetFileVersionInfoExW
#define GetFileVersionInfoSizeA      WINSDK_GetFileVersionInfoSizeA
#define GetFileVersionInfoSizeExA    WINSDK_GetFileVersionInfoSizeExA
#define GetFileVersionInfoSizeExW    WINSDK_GetFileVersionInfoSizeExW
#define GetFileVersionInfoSizeW      WINSDK_GetFileVersionInfoSizeW
#define GetFileVersionInfoW          WINSDK_GetFileVersionInfoW
#define VerFindFileA                 WINSDK_VerFindFileA
#define VerFindFileW                 WINSDK_VerFindFileW
#define VerInstallFileA              WINSDK_VerInstallFileA
#define VerInstallFileW              WINSDK_VerInstallFileW
#define VerLanguageNameA             WINSDK_VerLanguageNameA
#define VerLanguageNameW             WINSDK_VerLanguageNameW
#define VerQueryValueA               WINSDK_VerQueryValueA
#define VerQueryValueW               WINSDK_VerQueryValueW
#include <windows.h>
#undef GetFileVersionInfoA
#undef GetFileVersionInfoByHandle
#undef GetFileVersionInfoExA
#undef GetFileVersionInfoExW
#undef GetFileVersionInfoSizeA
#undef GetFileVersionInfoSizeExA
#undef GetFileVersionInfoSizeExW
#undef GetFileVersionInfoSizeW
#undef GetFileVersionInfoW
#undef VerFindFileA
#undef VerFindFileW
#undef VerInstallFileA
#undef VerInstallFileW
#undef VerLanguageNameA
#undef VerLanguageNameW
#undef VerQueryValueA
#undef VerQueryValueW

#include <stdint.h>
#include <wchar.h>

static HMODULE g_self = NULL;
static DWORD   g_pid = 0;
static HHOOK   g_hook = NULL;

static volatile LONG g_enabled = 1;
static volatile LONG g_kbmEnabled = 1;
static volatile LONG g_manualJogOverride = 0;
static volatile LONG g_suppressWalkKeyup = 0;

static int g_walkKey    = VK_LCONTROL; /* 0xA2 */
static int g_sprintKey  = VK_LSHIFT;   /* 0xA0 */
static int g_forwardKey = 'W';         /* 0x57 */
static int g_backKey    = 'S';         /* 0x53 */
static int g_leftKey    = 'A';         /* 0x41 */
static int g_rightKey   = 'D';         /* 0x44 */
static int g_toggleKey  = VK_F6;       /* 0x75 */

static volatile LONG g_walkInjectedDown = 0;

/* ------------------------------------------------------------------------- */
/* Real System32 version.dll proxy                                            */
/* ------------------------------------------------------------------------- */

static HMODULE g_realVersion = NULL;
static volatile LONG g_realVersionState = 0; /* 0 not started, 1 loading, 2 ready */

static FARPROC p_GetFileVersionInfoA = NULL;
static FARPROC p_GetFileVersionInfoByHandle = NULL;
static FARPROC p_GetFileVersionInfoExA = NULL;
static FARPROC p_GetFileVersionInfoExW = NULL;
static FARPROC p_GetFileVersionInfoSizeA = NULL;
static FARPROC p_GetFileVersionInfoSizeExA = NULL;
static FARPROC p_GetFileVersionInfoSizeExW = NULL;
static FARPROC p_GetFileVersionInfoSizeW = NULL;
static FARPROC p_GetFileVersionInfoW = NULL;
static FARPROC p_VerFindFileA = NULL;
static FARPROC p_VerFindFileW = NULL;
static FARPROC p_VerInstallFileA = NULL;
static FARPROC p_VerInstallFileW = NULL;
static FARPROC p_VerLanguageNameA = NULL;
static FARPROC p_VerLanguageNameW = NULL;
static FARPROC p_VerQueryValueA = NULL;
static FARPROC p_VerQueryValueW = NULL;

static void resolve_real_exports(void)
{
    if (!g_realVersion) return;

#define RESOLVE(name) p_##name = GetProcAddress(g_realVersion, #name)
    RESOLVE(GetFileVersionInfoA);
    RESOLVE(GetFileVersionInfoByHandle);
    RESOLVE(GetFileVersionInfoExA);
    RESOLVE(GetFileVersionInfoExW);
    RESOLVE(GetFileVersionInfoSizeA);
    RESOLVE(GetFileVersionInfoSizeExA);
    RESOLVE(GetFileVersionInfoSizeExW);
    RESOLVE(GetFileVersionInfoSizeW);
    RESOLVE(GetFileVersionInfoW);
    RESOLVE(VerFindFileA);
    RESOLVE(VerFindFileW);
    RESOLVE(VerInstallFileA);
    RESOLVE(VerInstallFileW);
    RESOLVE(VerLanguageNameA);
    RESOLVE(VerLanguageNameW);
    RESOLVE(VerQueryValueA);
    RESOLVE(VerQueryValueW);
#undef RESOLVE
}

static BOOL ensure_real_version(void)
{
    LONG state = InterlockedCompareExchange(&g_realVersionState, 1, 0);

    if (state == 0) {
        WCHAR path[MAX_PATH + 32];
        UINT n = GetSystemDirectoryW(path, MAX_PATH);
        if (n == 0 || n >= MAX_PATH) {
            InterlockedExchange(&g_realVersionState, 0);
            return FALSE;
        }

        if (path[n - 1] != L'\\') {
            path[n++] = L'\\';
            path[n] = L'\0';
        }

        static const WCHAR dllName[] = L"version.dll";
        if (n + (sizeof(dllName) / sizeof(dllName[0])) >= MAX_PATH + 32) {
            InterlockedExchange(&g_realVersionState, 0);
            return FALSE;
        }

        lstrcatW(path, dllName);
        g_realVersion = LoadLibraryW(path);

        if (!g_realVersion) {
            InterlockedExchange(&g_realVersionState, 0);
            return FALSE;
        }

        resolve_real_exports();
        InterlockedExchange(&g_realVersionState, 2);
        return TRUE;
    }

    while (InterlockedCompareExchange(&g_realVersionState, 0, 0) == 1)
        Sleep(1);

    return g_realVersion != NULL;
}

/* ------------------------------------------------------------------------- */
/* Keyboard movement logic                                                    */
/* ------------------------------------------------------------------------- */

static BOOL key_down(int vk)
{
    return (GetAsyncKeyState(vk) & 0x8000) != 0;
}

static BOOL physical_movement_any_down(void)
{
    return key_down(g_forwardKey) ||
           key_down(g_backKey) ||
           key_down(g_leftKey) ||
           key_down(g_rightKey);
}

static BOOL game_is_foreground(void)
{
    HWND hwnd = GetForegroundWindow();
    DWORD pid = 0;

    if (!hwnd) return FALSE;
    GetWindowThreadProcessId(hwnd, &pid);
    return pid == g_pid;
}

static BOOL sprint_is_down(void)
{
    /* The supplied binary recognizes Shift as sprint. Keep both Shift sides
       usable when the default LShift binding is selected. */
    if (g_sprintKey == VK_LSHIFT || g_sprintKey == VK_SHIFT) {
        return key_down(VK_LSHIFT) || key_down(VK_RSHIFT) || key_down(VK_SHIFT);
    }
    return key_down(g_sprintKey);
}

static void send_walk_key(BOOL down)
{
    LONG wasDown = InterlockedCompareExchange(&g_walkInjectedDown, 0, 0);

    if ((down && wasDown) || (!down && !wasDown))
        return;

    INPUT in;
    ZeroMemory(&in, sizeof(in));
    in.type = INPUT_KEYBOARD;
    in.ki.wVk = (WORD)g_walkKey;
    in.ki.dwFlags = down ? 0 : KEYEVENTF_KEYUP;

    if (SendInput(1, &in, sizeof(in)) == 1)
        InterlockedExchange(&g_walkInjectedDown, down ? 1 : 0);
}

static LRESULT CALLBACK manual_ctrl_hook(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode >= 0 && lParam) {
        const KBDLLHOOKSTRUCT *k = (const KBDLLHOOKSTRUCT *)lParam;

        /* Ignore our own SendInput events. */
        if ((k->flags & LLKHF_INJECTED) == 0) {
            BOOL isWalkKey = ((int)k->vkCode == g_walkKey);

            /* Preserve the original Ctrl scan-code fallback used by the
               supplied binary when the default walk key is active. */
            if (g_walkKey == VK_LCONTROL &&
                (k->vkCode == VK_CONTROL || k->vkCode == VK_LCONTROL) &&
                k->scanCode == 0x1D) {
                isWalkKey = TRUE;
            }

            if (isWalkKey &&
                InterlockedCompareExchange(&g_kbmEnabled, 0, 0) &&
                InterlockedCompareExchange(&g_enabled, 0, 0) &&
                game_is_foreground() &&
                physical_movement_any_down()) {

                BOOL isDown = (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN);
                BOOL isUp   = (wParam == WM_KEYUP   || wParam == WM_SYSKEYUP);

                if (isDown &&
                    InterlockedCompareExchange(&g_manualJogOverride, 0, 0) == 0) {
                    InterlockedExchange(&g_manualJogOverride, 1);
                    InterlockedExchange(&g_suppressWalkKeyup, 1);
                    return 1; /* do not let this physical press become a walk */
                }

                if (isUp &&
                    InterlockedCompareExchange(&g_suppressWalkKeyup, 0, 0)) {
                    InterlockedExchange(&g_suppressWalkKeyup, 0);
                    return 1;
                }
            }
        }
    }

    return CallNextHookEx(g_hook, nCode, wParam, lParam);
}

static DWORD WINAPI manual_hook_thread(LPVOID unused)
{
    MSG msg;
    (void)unused;

    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, manual_ctrl_hook, g_self, 0);
    if (!g_hook)
        return 0;

    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    UnhookWindowsHookEx(g_hook);
    g_hook = NULL;
    return 0;
}

static void load_ini(void)
{
    WCHAR path[MAX_PATH];
    WCHAR *slash;

    if (!GetModuleFileNameW(g_self, path, MAX_PATH))
        return;

    slash = wcsrchr(path, L'\\');
    if (slash)
        *(slash + 1) = L'\0';
    else
        path[0] = L'\0';

    lstrcatW(path, L"blackflag_movement.ini");

    InterlockedExchange(
        &g_kbmEnabled,
        GetPrivateProfileIntW(L"KeyboardMouse", L"KeyboardWalkByDefault", 1, path) ? 1 : 0);

    g_walkKey = GetPrivateProfileIntW(
        L"KeyboardMouse", L"KeyboardWalkKey", VK_LCONTROL, path);

    g_sprintKey = GetPrivateProfileIntW(
        L"KeyboardMouse", L"KeyboardSprintKey", VK_LSHIFT, path);

    g_forwardKey = GetPrivateProfileIntW(
        L"KeyboardMouse", L"KeyboardForwardKey", 'W', path);

    g_backKey = GetPrivateProfileIntW(
        L"KeyboardMouse", L"KeyboardBackKey", 'S', path);

    g_leftKey = GetPrivateProfileIntW(
        L"KeyboardMouse", L"KeyboardLeftKey", 'A', path);

    g_rightKey = GetPrivateProfileIntW(
        L"KeyboardMouse", L"KeyboardRightKey", 'D', path);

    g_toggleKey = GetPrivateProfileIntW(
        L"KeyboardMouse", L"KeyboardToggleKey", VK_F6, path);
}

static DWORD WINAPI keyboard_thread(LPVOID unused)
{
    BOOL oldToggle = FALSE;
    (void)unused;

    g_pid = GetCurrentProcessId();
    load_ini();

    {
        HANDLE h = CreateThread(NULL, 0, manual_hook_thread, NULL, 0, NULL);
        if (h) CloseHandle(h);
    }

    for (;;) {
        BOOL focused = game_is_foreground();
        BOOL toggleDown = key_down(g_toggleKey);

        if (focused && toggleDown && !oldToggle) {
            LONG newState = !InterlockedCompareExchange(&g_enabled, 0, 0);
            InterlockedExchange(&g_enabled, newState);
            if (!newState) {
                send_walk_key(FALSE);
                InterlockedExchange(&g_manualJogOverride, 0);
                InterlockedExchange(&g_suppressWalkKeyup, 0);
            }
        }
        oldToggle = toggleDown;

        if (!InterlockedCompareExchange(&g_kbmEnabled, 0, 0) ||
            !InterlockedCompareExchange(&g_enabled, 0, 0) ||
            !focused) {
            send_walk_key(FALSE);
            if (!focused) {
                InterlockedExchange(&g_manualJogOverride, 0);
                InterlockedExchange(&g_suppressWalkKeyup, 0);
            }
            Sleep(8);
            continue;
        }

        {
            BOOL moving = physical_movement_any_down();

            if (!moving) {
                send_walk_key(FALSE);
                InterlockedExchange(&g_manualJogOverride, 0);
                InterlockedExchange(&g_suppressWalkKeyup, 0);
            } else if (sprint_is_down() ||
                       InterlockedCompareExchange(&g_manualJogOverride, 0, 0)) {
                send_walk_key(FALSE);
            } else {
                /* Default movement state: hold the game's native walk key. */
                send_walk_key(TRUE);
            }
        }

        Sleep(8);
    }
}

/* ------------------------------------------------------------------------- */
/* Export wrappers                                                            */
/* ------------------------------------------------------------------------- */

#define NEED_REAL(p, failure) do { \
    if (!ensure_real_version() || !(p)) { SetLastError(ERROR_PROC_NOT_FOUND); return (failure); } \
} while (0)

__declspec(dllexport)
BOOL WINAPI GetFileVersionInfoA(LPCSTR a, DWORD b, DWORD c, LPVOID d)
{
    typedef BOOL (WINAPI *FN)(LPCSTR,DWORD,DWORD,LPVOID);
    NEED_REAL(p_GetFileVersionInfoA, FALSE);
    return ((FN)p_GetFileVersionInfoA)(a,b,c,d);
}

__declspec(dllexport)
BOOL WINAPI GetFileVersionInfoByHandle(DWORD a, HANDLE b, DWORD c, LPVOID d)
{
    typedef BOOL (WINAPI *FN)(DWORD,HANDLE,DWORD,LPVOID);
    NEED_REAL(p_GetFileVersionInfoByHandle, FALSE);
    return ((FN)p_GetFileVersionInfoByHandle)(a,b,c,d);
}

__declspec(dllexport)
BOOL WINAPI GetFileVersionInfoExA(DWORD a, LPCSTR b, DWORD c, DWORD d, LPVOID e)
{
    typedef BOOL (WINAPI *FN)(DWORD,LPCSTR,DWORD,DWORD,LPVOID);
    NEED_REAL(p_GetFileVersionInfoExA, FALSE);
    return ((FN)p_GetFileVersionInfoExA)(a,b,c,d,e);
}

__declspec(dllexport)
BOOL WINAPI GetFileVersionInfoExW(DWORD a, LPCWSTR b, DWORD c, DWORD d, LPVOID e)
{
    typedef BOOL (WINAPI *FN)(DWORD,LPCWSTR,DWORD,DWORD,LPVOID);
    NEED_REAL(p_GetFileVersionInfoExW, FALSE);
    return ((FN)p_GetFileVersionInfoExW)(a,b,c,d,e);
}

__declspec(dllexport)
DWORD WINAPI GetFileVersionInfoSizeA(LPCSTR a, LPDWORD b)
{
    typedef DWORD (WINAPI *FN)(LPCSTR,LPDWORD);
    NEED_REAL(p_GetFileVersionInfoSizeA, 0);
    return ((FN)p_GetFileVersionInfoSizeA)(a,b);
}

__declspec(dllexport)
DWORD WINAPI GetFileVersionInfoSizeExA(DWORD a, LPCSTR b, LPDWORD c)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPCSTR,LPDWORD);
    NEED_REAL(p_GetFileVersionInfoSizeExA, 0);
    return ((FN)p_GetFileVersionInfoSizeExA)(a,b,c);
}

__declspec(dllexport)
DWORD WINAPI GetFileVersionInfoSizeExW(DWORD a, LPCWSTR b, LPDWORD c)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPCWSTR,LPDWORD);
    NEED_REAL(p_GetFileVersionInfoSizeExW, 0);
    return ((FN)p_GetFileVersionInfoSizeExW)(a,b,c);
}

__declspec(dllexport)
DWORD WINAPI GetFileVersionInfoSizeW(LPCWSTR a, LPDWORD b)
{
    typedef DWORD (WINAPI *FN)(LPCWSTR,LPDWORD);
    NEED_REAL(p_GetFileVersionInfoSizeW, 0);
    return ((FN)p_GetFileVersionInfoSizeW)(a,b);
}

__declspec(dllexport)
BOOL WINAPI GetFileVersionInfoW(LPCWSTR a, DWORD b, DWORD c, LPVOID d)
{
    typedef BOOL (WINAPI *FN)(LPCWSTR,DWORD,DWORD,LPVOID);
    NEED_REAL(p_GetFileVersionInfoW, FALSE);
    return ((FN)p_GetFileVersionInfoW)(a,b,c,d);
}

__declspec(dllexport)
DWORD WINAPI VerFindFileA(DWORD a,LPCSTR b,LPCSTR c,LPCSTR d,LPSTR e,PUINT f,LPSTR g,PUINT h)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPCSTR,LPCSTR,LPCSTR,LPSTR,PUINT,LPSTR,PUINT);
    NEED_REAL(p_VerFindFileA, 0);
    return ((FN)p_VerFindFileA)(a,b,c,d,e,f,g,h);
}

__declspec(dllexport)
DWORD WINAPI VerFindFileW(DWORD a,LPCWSTR b,LPCWSTR c,LPCWSTR d,LPWSTR e,PUINT f,LPWSTR g,PUINT h)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPCWSTR,LPCWSTR,LPCWSTR,LPWSTR,PUINT,LPWSTR,PUINT);
    NEED_REAL(p_VerFindFileW, 0);
    return ((FN)p_VerFindFileW)(a,b,c,d,e,f,g,h);
}

__declspec(dllexport)
DWORD WINAPI VerInstallFileA(DWORD a,LPCSTR b,LPCSTR c,LPCSTR d,LPCSTR e,LPCSTR f,LPSTR g,PUINT h)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPCSTR,LPCSTR,LPCSTR,LPCSTR,LPCSTR,LPSTR,PUINT);
    NEED_REAL(p_VerInstallFileA, 0);
    return ((FN)p_VerInstallFileA)(a,b,c,d,e,f,g,h);
}

__declspec(dllexport)
DWORD WINAPI VerInstallFileW(DWORD a,LPCWSTR b,LPCWSTR c,LPCWSTR d,LPCWSTR e,LPCWSTR f,LPWSTR g,PUINT h)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPWSTR,PUINT);
    NEED_REAL(p_VerInstallFileW, 0);
    return ((FN)p_VerInstallFileW)(a,b,c,d,e,f,g,h);
}

__declspec(dllexport)
DWORD WINAPI VerLanguageNameA(DWORD a, LPSTR b, DWORD c)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPSTR,DWORD);
    NEED_REAL(p_VerLanguageNameA, 0);
    return ((FN)p_VerLanguageNameA)(a,b,c);
}

__declspec(dllexport)
DWORD WINAPI VerLanguageNameW(DWORD a, LPWSTR b, DWORD c)
{
    typedef DWORD (WINAPI *FN)(DWORD,LPWSTR,DWORD);
    NEED_REAL(p_VerLanguageNameW, 0);
    return ((FN)p_VerLanguageNameW)(a,b,c);
}

__declspec(dllexport)
BOOL WINAPI VerQueryValueA(LPCVOID a, LPCSTR b, LPVOID *c, PUINT d)
{
    typedef BOOL (WINAPI *FN)(LPCVOID,LPCSTR,LPVOID*,PUINT);
    NEED_REAL(p_VerQueryValueA, FALSE);
    return ((FN)p_VerQueryValueA)(a,b,c,d);
}

__declspec(dllexport)
BOOL WINAPI VerQueryValueW(LPCVOID a, LPCWSTR b, LPVOID *c, PUINT d)
{
    typedef BOOL (WINAPI *FN)(LPCVOID,LPCWSTR,LPVOID*,PUINT);
    NEED_REAL(p_VerQueryValueW, FALSE);
    return ((FN)p_VerQueryValueW)(a,b,c,d);
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved)
{
    (void)reserved;

    if (reason == DLL_PROCESS_ATTACH) {
        HANDLE h;
        g_self = instance;
        DisableThreadLibraryCalls(instance);

        h = CreateThread(NULL, 0, keyboard_thread, NULL, 0, NULL);
        if (h) CloseHandle(h);
    }

    return TRUE;
}
