@echo off
setlocal
cd /d "%~dp0"
where cl.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: cl.exe was not found.
  echo Open "x86 Native Tools Command Prompt for VS" and run this file again.
  pause
  exit /b 1
)
if not exist Build\x86 mkdir Build\x86
cl.exe /nologo /O2 /W4 /LD /D_CRT_SECURE_NO_WARNINGS blackflag_movement.c ^
  /link /DEF:version.def /OUT:Build\x86\version.dll /SUBSYSTEM:WINDOWS
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)
echo.
echo BUILD OK: Source\Build\x86\version.dll
pause
