WALK MOD KBM - ACBFR
REBUILT DEVELOPMENT PACKAGE WITH SOURCE

This package preserves the known-working runtime behavior of the supplied mod
and adds a complete development/source folder.

RUNTIME
-------
32bit (Steam-Ubisoft)
  version.dll
  blackflag_movement.ini

64bit (DX12)
  version.dll
  blackflag_movement.ini

SOURCE
------
Source\blackflag_movement.c
Source\version.def
Source\Build x86.bat
Source\Build x64.bat
Source\README_SOURCE.txt
Source\ORIGINAL_RUNTIME_SHA256.txt

CONTROLS / BEHAVIOR
-------------------
- WASD: walk by default
- Native walk-key tap while moving: jog override
- Stopping movement: reset to walk
- Hold Shift: sprint
- Release Shift: return to the active walk/jog state
- F6: toggle the movement modification
- Modification is limited to the game while it owns foreground focus

IMPORTANT SOURCE NOTE
---------------------
The supplied RAR did not include the original compiler source. The included
source is a readable/buildable reconstruction based on the supplied DLLs'
exports, imported APIs, configuration keys, symbols and observed control flow.

The supplied known-working x86/x64 runtime DLLs are preserved unchanged so this
development package functions exactly like the supplied mod. Rebuilding the
source with a different compiler/toolchain can produce different binary bytes.
